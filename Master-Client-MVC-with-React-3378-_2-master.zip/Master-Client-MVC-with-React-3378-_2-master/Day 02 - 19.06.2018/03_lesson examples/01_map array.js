
const names = ['Alice', 'Bob', 'Tom'];

names.map(function (name, index) {
  console.log(` person number ${index}> : Hello ${name}!`)
});


/*
OUTPUT:
________________
 person number 0> : Hello Alice!
 person number 1> : Hello Bob!
 person number 2> : Hello Tom!
*/

