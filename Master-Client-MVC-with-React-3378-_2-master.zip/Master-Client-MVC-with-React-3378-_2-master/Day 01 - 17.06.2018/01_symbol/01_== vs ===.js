let num1=1;
let str="1";
console.log(`num1== str ${num1== str}`);
console.log(`num1=== str ${num1=== str}`);


/*

OUTPUT:
____________________________

num1== str true
num1=== str false
*/ 