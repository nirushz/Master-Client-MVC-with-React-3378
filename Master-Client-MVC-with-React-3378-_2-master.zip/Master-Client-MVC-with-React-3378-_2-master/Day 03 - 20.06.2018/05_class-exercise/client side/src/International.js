import React from 'react';
let international = (p) => {
    return <div>
        <h1>International</h1>
        <a href="https://en.wikipedia.org/wiki/International">see International in wiki</a>
    </div>
};

export default international;

