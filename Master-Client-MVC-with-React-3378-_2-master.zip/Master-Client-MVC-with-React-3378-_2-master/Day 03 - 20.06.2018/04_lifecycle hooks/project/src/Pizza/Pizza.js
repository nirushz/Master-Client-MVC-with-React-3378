import React from 'react';


const pizza = (p) => {

    console.log("pizza function");
    return (<div>
        <p>Pizza price: {p.price}</p>
    </div>);
}

export default pizza;