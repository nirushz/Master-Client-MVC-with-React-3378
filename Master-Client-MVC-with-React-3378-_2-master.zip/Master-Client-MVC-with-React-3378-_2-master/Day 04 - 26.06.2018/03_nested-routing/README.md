# Steps to create a react project using routing:
* Create react app with this command:
```bash
create-react-app proj
```
* change the cmd path to the new project that you created:
```bash
cd proj
```
* install local to the project a package that will give the routing options:
```bash
npm i -s react-router-dom
```
