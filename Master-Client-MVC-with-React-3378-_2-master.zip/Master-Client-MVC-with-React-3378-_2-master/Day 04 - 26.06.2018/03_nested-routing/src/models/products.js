
const products = [
    {
        name: '3% milk',
        id: 'milk',
        description: 'milk is the best'
    },
    {
        name: 'sweet corn',
        id: 'corn',
        description: 'hot sweet corn'
       
    },
    {
        name: 'veg salad',
        id: 'salad',
        description: 'healthy colorfull salad'
       
    }
]

export default products;