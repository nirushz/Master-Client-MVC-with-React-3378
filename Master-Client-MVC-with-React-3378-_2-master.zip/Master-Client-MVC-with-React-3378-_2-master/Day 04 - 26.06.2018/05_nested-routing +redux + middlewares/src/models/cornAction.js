//this will be used as the types of the redux actions

export const cornAction = {
    ADD_SUCCESS: 'CORN_ADD_SUCCESS',
    ADD_REQUEST: 'CORN_ADD_REQUEST',
    ADD_FAIL: 'CORN_ADD_FAIL',
    REMOVE: 'CORN_REMOVE'
};

