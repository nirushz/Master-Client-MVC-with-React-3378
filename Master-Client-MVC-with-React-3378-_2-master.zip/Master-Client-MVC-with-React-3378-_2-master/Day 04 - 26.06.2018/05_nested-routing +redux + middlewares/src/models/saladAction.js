//this will be used as the types of the redux actions

export const saladAction = {
    ADD_SUCCESS: 'SALAD_ADD_SUCCESS',
    ADD_REQUEST: 'SALAD_ADD_REQUEST',
    ADD_FAIL: 'SALAD_ADD_FAIL',
    REMOVE: 'SALAD_REMOVE'
};

