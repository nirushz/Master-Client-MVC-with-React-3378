//this will be used as the types of the redux actions

export const milkAction = {
    ADD_SUCCESS: 'MILK_ADD_SUCCESS',
    ADD_REQUEST: 'MILK_ADD_REQUEST',
    ADD_FAIL: 'MILK_ADD_FAIL',
    REMOVE: 'MILK_REMOVE'
};

