var a1 = 4;
//a1 = "test"  //Type 'string' is not assignable to type 'number'.	
var a2 = "Test";
a2 = f1(3, true);
var a3 = true;
var a4 = 4;
a4 = "hello";
a4 = true;
function f1(param1, param2) {
    return param1 + " and " + param2;
}
var dog1 = new Dog(12, "Tom");
var dog2 = new Dog(12, "Tom");
var dog3 = new Dog(12, "Tom");
console.log(dog2.age); //Down casting
console.log(dog2.age); //Down casting
//# sourceMappingURL=app.js.map