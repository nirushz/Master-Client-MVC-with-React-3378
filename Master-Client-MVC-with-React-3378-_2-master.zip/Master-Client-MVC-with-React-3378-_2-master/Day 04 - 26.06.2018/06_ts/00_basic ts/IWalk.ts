﻿interface IWalk {
    walkRight(): void;
}