var Animal = (function () {
    function Animal(ageParam, nameParm) {
        this.age = ageParam;
        this.firstName = nameParm;
    }
    return Animal;
}());
//# sourceMappingURL=Animal.js.map